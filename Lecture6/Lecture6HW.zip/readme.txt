Your homework will be to pick a sport and build a Bayesian model on the sport or on select teams, and be able to do some predictions.

You need to base your model on a simple linear combination of independent variables, in order to be able to get a better handle on a dependent variable. You can use a simple linear model, a log-linear model, or a linear-logistic model. But I don't want to see anything else because it's probably going to be a copy from the Web.

It is ok to reference previous work from the Web as long as your work is not a plain copy of something somebody else did. Your TAs are just as capable as you are to google and find work that you may have copied from, SO DON'T DO THIS. Do your own study, it is ok in science to publish a paper that has negative results: not able to do what you started off doing, as long as you explain why you think the effort failed.

Work in teams of 2, not more. Best HW will be presented in class.

-dino & TAs